# Define the __version__ attribute
__version__ = "0.0.2"
